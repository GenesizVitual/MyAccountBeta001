CREATE TRIGGER hapus_jurnal_penjualan_dihapus
AFTER DELETE ON penjualan
FOR EACH ROW
  BEGIN
	/*DELETE from jurnal WHERE jurnal.id_penjualan = old.id;*/
END;
