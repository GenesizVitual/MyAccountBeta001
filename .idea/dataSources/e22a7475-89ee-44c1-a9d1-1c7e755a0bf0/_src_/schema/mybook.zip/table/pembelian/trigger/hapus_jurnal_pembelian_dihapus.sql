CREATE TRIGGER hapus_jurnal_pembelian_dihapus
AFTER DELETE ON pembelian
FOR EACH ROW
  BEGIN
/* delete from jurnal WHERE jurnal.id_pembelian = old.id;*/
END;
